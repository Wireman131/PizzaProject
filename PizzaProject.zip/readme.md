Tony and Dave's Pizza Place
===========================

Self contained pizza shop.  Complete with client and server side validation
for all input fields.  
-Custom built Captcha
-Email notification via Swiftmailer PHP library

Thanks go out to:
============================
-Water Street Coffee (Without you, this could have never happened)

