<?php
/*                   ____
 *             _,--~~    ~~--._
 *           ,/'  m%%%%%%=@%%m  `\.
 *          /' m%%o(_)%%o%%%%o%%m `\
 *        /' %%@=%o%%%o%%%o%(_)o%%% `\
 *       /  %o%%%%%=@%%%(_)%%o%%@=%%  \
 *      |  (_)%(_)%%o%%%o%%%%=@(_)%%%  |
 *      | %%o%%%%o%%%(_)%%o%%o%%%%o%%% |
 *      | %%o%(_)%%%  o%(_)%%%o%%o%o%% |
 *      |  (_)%%=@    %o%o%%(_)%o(_)%  |
 *  	   \  ~%%o      %o%=@%%o%%@%%o%~ /
 *		    \ .         %%o%(_)%%(_)o~ ,/
 *			             _)%o%%(_)%~   _/
 *	                 %%%o%%%%%~~_/'
 *                   ..____,,--'
 *            /\
 *           /  \
 *            ||
 *             \\_ 
 *              -- http://www.ascii-art.de/ascii/pqr/pizza.txt
 *
 *
 * 
 * Description Short
 *
 * Description Long
 *
 * @author			Tony Gaudio & David Sullivan
 * @category   
 * @package    
 * @version    
 * @link       git@github.com:
 * @since      Mar 11, 2011-2011
*/
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Advanced PHP Pizza Shop</title>
<?php
echo '<link rel="stylesheet" type="text/css" href="base.css"/>';
//echo '<script src="library' . SLASH . 'jquery' . SLASH . '1.5.1'  . SLASH .  'jquery.js" type="text/javascript"></script>';
//echo '<script src="library' . SLASH . 'jquery-validation' . SLASH . 'jquery.validate.js" type="text/javascript"></script>';
//echo '<script src="library' . SLASH . 'jquery-validation' . SLASH . 'additional-methods.js" type="text/javascript"></script>';
echo '<script src="library/jquery/1.5.1/jquery.js" type="text/javascript"></script>';
echo '<script src="library/jquery-validation/jquery.validate.js" type="text/javascript"></script>';
echo '<script src="library/jquery-validation/additional-methods.js" type="text/javascript"></script>';
echo '<script src="Project 2.js" type="text/javascript"></script>';
echo '<script src="pizza_jQuery.js" type="text/javascript"></script>';

?>
