<?php
/*
 * I'm hoping that eventual I'll be able to fill this with a set of modes for
 * every occasion.
 */
function myRegEx($string, $mode){
/*
 * English name 
 */
if($mode == "name_en"){
	//some regex test for a capital first letter follow by lower case letters, 
}
/*
 * I'm hoping that eventual I'll be able to fill this with a set of modes for
 * every occasion.
 */

}
