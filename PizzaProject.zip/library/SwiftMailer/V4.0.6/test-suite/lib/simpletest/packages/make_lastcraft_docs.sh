#!/bin/bash
php transform_all_lastcraft.php lastcraft.xslt ../docs/source/en/ ../docs/lastcraft/
