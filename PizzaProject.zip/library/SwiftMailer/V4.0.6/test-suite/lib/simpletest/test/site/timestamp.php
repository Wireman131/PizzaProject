<?php
    print time();
?>